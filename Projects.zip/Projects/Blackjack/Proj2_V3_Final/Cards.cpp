/* 
 * File:   Cards.cpp
 * Author: mac
 *
 * Created on July 29, 2021, 12:55 PM
 */

#include <iostream>  //I/O Library
#include "Cards.h"
using namespace std;

void CardInfo::setCardNum(int a) {
    cardnum=a;
}

void CardInfo::setCardName(string a) {
    cardname=a;
}